package `in`.co.rohilla.wifimonitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
